/**
 * Lab 1
 *
 * @author: Yash Mishra
 * This is the CIS22C Class. It is a subclass of the Dollar Class.
 * Lab One is meant to represent a Currency Simulator.
 */


public class CIS22CDollar extends Dollar {
    private double factor = 1.36;

    /**
     * get method for factor
     * @return factor
     */
    public double getFactor() {
        return factor;
    }

    /**
     * creates a new CIS22CDollar Object with a value of 0
     */
    public CIS22CDollar() {
        super.setWholePart(0);
        super.setFractionalPart(0);
        super.setNoteName("CIS22C dollar");
    }

    /**
     * Constructs a CIS22CDollar with given parameters
     *
     * @param wholePart      integer whole part of the CIS22CDollar
     * @param fractionalPart integer fractional part of the CIS22CDollar
     * @param noteName       name of currency
     */
    public CIS22CDollar(int wholePart, int fractionalPart, String noteName) {
        super(wholePart, fractionalPart, noteName);
    }

    /**
     * Copy constructor for CIS22CDollar
     *
     * @param c Dollar to be copied
     */
    public CIS22CDollar(CIS22CDollar c) {
        this.setWholePart(c.getWholePart());
        this.setFractionalPart(c.getFractionalPart());
        this.setNoteName(c.getNoteName());
    }

    /**
     * adds CIS22CDollars and considers that 100 fractional parts changes the whole part value
     * PRE: takes in a CIS22CDollar object
     * POST: adds the CIS22CDollar object
     * @param c CIS22CDollar to be added
     */
    public void add(CIS22CDollar c) {

        this.setWholePart(this.getWholePart() + c.getWholePart());
        this.setFractionalPart(this.getFractionalPart() + c.getFractionalPart());

        while (this.getFractionalPart() >= 1000) {
            this.setFractionalPart(this.getFractionalPart() - 1000);
            this.setWholePart(this.getWholePart() + 1);
        }

        while (this.getFractionalPart() < 0) {
            this.setFractionalPart(this.getFractionalPart() + 1000);
            this.setWholePart(this.getWholePart() - 1);
        }

    }

    /**
     * subtracts CIS22CDollars and considers that 100 fractional parts changes the whole part value
     * PRE: takes in a CIS22CDollar object
     * POST: subtracts the CIS22CDollar object
     * @param c CIS22CDollar to be subtracted
     */
    public void subtract(CIS22CDollar c) {
        this.setWholePart(this.getWholePart() - c.getWholePart());
        this.setFractionalPart(this.getFractionalPart() - c.getFractionalPart());

        while (this.getFractionalPart() >= 1000) {
            this.setFractionalPart(this.getFractionalPart() - 1000);
            this.setWholePart(this.getWholePart() + 1);
        }

        while (this.getFractionalPart() < 0) {
            this.setFractionalPart(this.getFractionalPart() + 1000);
            this.setWholePart(this.getWholePart() - 1);
        }

    }

    /**
     * checks if the CIS22CDollar object is equal to another
     * @param c CIS22CDollar object being compared to
     * @return true if the CIS22CDollar objects are equal, false otherwise
     */
    public boolean equals(CIS22CDollar c) {
        return this.getWholePart() == c.getWholePart() && this.getFractionalPart() == c.getFractionalPart();
    }

    /**
     * checks if one CIS22CDollar object has a greater value than another
     * @param c CIS22CDollar object being compared to
     * @return this CIS22CDollar object if it has greater value, CIS22CDollar d otherwise
     */
    public CIS22CDollar biggerCIS22CDollar(CIS22CDollar c) {
        if (this.getWholePart() > c.getWholePart()) {
            return this;
        } else if (this.getWholePart() == c.getWholePart()) {
            if (this.getWholePart() > c.getFractionalPart()) {
                return this;
            } else {
                return c;
            }
        } else {
            return c;
        }
    }

    /**
     * Converts a CIS22CDollar into a US dollar
     * @param c CIS22CDollar that is to be converted
     * @return Dollar object with equivalent value of parameter
     */
    public Dollar convert(CIS22CDollar c) {
        int value = c.getWholePart() * 1000 + c.getFractionalPart();
        double dollarValue = (double) value / getFactor();
        int beforeDecimal = (int) (dollarValue / 1000.0);
        int afterDecimal = (int) (dollarValue % 1000.0);
        return new Dollar(beforeDecimal, afterDecimal, "US dollar");
    }

    /**
     * Converts a Dollar into a CIS22CDollar
     * @param d Dollar that is to be converted
     * @return CIS22CDollar object with equivalent value of parameter
     */
    public CIS22CDollar convert(Dollar d) {
        int value = d.getWholePart() * 1000 + d.getFractionalPart();
        double CIS22CDollarValue = (double) value * getFactor();
        int beforeDecimal = (int) (CIS22CDollarValue / 1000.0);
        int afterDecimal = (int) (CIS22CDollarValue % 1000.0);
        return new CIS22CDollar(beforeDecimal, afterDecimal, "CIS22C dollar");
    }
}