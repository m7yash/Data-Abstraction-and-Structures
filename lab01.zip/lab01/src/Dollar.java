
/**
 * Lab 1
 *
 * @author: Yash Mishra
 * This is the Dollar Class. Each dollar has a Note Name, Whole Part, and Fractional Part.
 * Lab One is meant to represent a Currency Simulator.
 */

public class Dollar {
    private int wholePart;
    private int fractionalPart;
    private String noteName;

    /**
     * Constructs a US Dollar set to 0 whole parts and 0 fractional parts
     */
    public Dollar() {
        this.wholePart = 0;
        this.fractionalPart = 0;
        this.noteName = "US dollar";
    }

    /**
     * Constructs a US Dollar with given parameters
     *
     * @param wholePart      integer whole part of the dollar
     * @param fractionalPart integer fractional part of th CIS22CDollar
     * @param noteName       name of currency
     */
    public Dollar(int wholePart, int fractionalPart, String noteName) {
        this.wholePart = wholePart;
        this.fractionalPart = fractionalPart;
        this.noteName = noteName;
    }

    /**
     * Copy constructor for Dollar
     *
     * @param d Dollar to be copied
     */
    public Dollar(Dollar d) {
        this.wholePart = d.getWholePart();
        this.fractionalPart = d.getFractionalPart();
        this.noteName = d.getNoteName();
    }

    /**
     * print method that reports the name and value of the currency
     * PRE: none
     * POST: prints a report
     */
    public void print() {
        System.out.println(getNoteName() + " value: " + getWholePart() + " dollars and " + getFractionalPart() + " parts.");
    }

    /**
     * adds Dollars and considers that 100 fractional parts changes the whole part value
     * PRE: takes in a Dollar object
     * POST: adds the dollar object
     * @param d Dollar to be added
     */
    public void add(Dollar d) {
        this.wholePart += d.getWholePart();

        for (this.fractionalPart += d.getFractionalPart(); this.fractionalPart >= 100; ++this.wholePart) {
            this.fractionalPart -= 100;
        }

        while (this.fractionalPart < 0) {
            this.fractionalPart += 100;
            --this.wholePart;
        }

    }

    /**
     * subtracts Dollars and considers that 100 fractional parts changes the whole part value
     * PRE: takes in a Dollar object
     * POST: subtracts the dollar object
     * @param d Dollar to be subtracted
     */
    public void subtract(Dollar d) {
        this.wholePart -= d.getWholePart();

        for (this.fractionalPart -= d.getFractionalPart(); this.fractionalPart >= 100; ++this.wholePart) {
            this.fractionalPart -= 100;
        }

        while (this.fractionalPart < 0) {
            this.fractionalPart += 100;
            --this.wholePart;
        }

    }

    /**
     * checks if the Dollar object is equal to another
     * @param d Dollar object being compared to
     * @return true if the Dollar objects are equal, false otherwise
     */
    public boolean equals(Dollar d) {
        return this.wholePart == d.getWholePart() && this.fractionalPart == d.getFractionalPart();
    }

    /**
     * checks if one Dollar object has a greater value than another
     * @param d Dollar object being compared to
     * @return this Dollar object if it has greater value, Dollar d otherwise
     */
    public Dollar biggerDollar(Dollar d) {
        if (this.wholePart > d.getWholePart()) {
            return this;
        } else if (this.wholePart == d.getWholePart()) {
            if (this.fractionalPart > d.getFractionalPart()) {
                return this;
            } else {
                return d;
            }
        } else {
            return d;
        }
    }

    /**
     * get method for whole part
     * @return whole part value
     */
    public int getWholePart() {
        return this.wholePart;
    }

    /**
     * set method for whole part
     * @param wholePart is new whole Part that the field will change to
     */
    public void setWholePart(int wholePart) {
        this.wholePart = wholePart;
    }

    /**
     * get method for fractional part
     * @return fractional part value
     */
    public int getFractionalPart() {
        return this.fractionalPart;
    }

    /**
     * set method for fractional part
     * @param fractionalPart is new fractional Part that the field will change to
     */
    public void setFractionalPart(int fractionalPart) {
        this.fractionalPart = fractionalPart;
    }

    /**
     * get method for note name
     * @return name of the currency
     */
    public String getNoteName() {
        return this.noteName;
    }

    /**
     * set method for note Name
     * @param noteName is new noteName that the field will change to
     */
    public void setNoteName(String noteName) {
        this.noteName = noteName;
    }

}