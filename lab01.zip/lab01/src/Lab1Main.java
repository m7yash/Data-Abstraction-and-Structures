/**
 * Lab 1
 *
 * @author: Yash Mishra
 * This is the Main Class for Lab One. Takes user input and lets them add/subtract/compare/print currency in a Wallet.
 * Lab One is meant to represent a Currency Simulator.
 */

import java.util.Scanner;

/**
 * Main Class of Program.
 */
public class Lab1Main {
    static Scanner sc = new Scanner(System.in);
    private static Wallet w;

    /**
     * Main method that initializes a wallet and takes user input
     * @param args args of main method
     */
    public static void main(String[] args) {
        w = new Wallet();
        while (true) {
            System.out.println("Type a to add, s to subtract, c to compare the values in the wallet, p to print the contents of the wallet, or e to exit");
            String command = sc.next();
            if (!command.equals("a") && !command.equals("s")) {
                if (command.equals("c")) {
                    Dollar d = w.getBills()[0];
                    CIS22CDollar c = (CIS22CDollar) w.getBills()[1];
                    Dollar d2 = c.convert(c); //US Dollar Value of CIS22CDollar
                    if (d.equals(d2)) {
                        System.out.println("The US and CIS22C Dollars have equal value in this wallet.");
                    } else if (w.greaterThanDollarTotal(d2)) {
                        System.out.println("CISS22C Dollars have greater value in this wallet.");
                    } else {
                        System.out.println("US Dollars have greater value in this wallet.");
                    }
                } else if (command.equals("p")) {
                    w.print();
                } else {
                    if (command.equals("e")) {
                        return;
                    }
                    System.out.println("Command not recognized. Please try again.");
                }
            } else {
                changeValues(command);
                System.out.println("process complete");
            }
        }
    }

    /**
     * PRE: command about addition or subtraction
     * POST: value is added or subtracted from the correct currency in the Wallet
     * helper method for main method
     * @param command command provided from main method indicating addition or subtraction
     */
    public static void changeValues(String command) {
        boolean adding = command.equals("a");
        String action = "";
        if (adding) {
            action = "add to";
        } else {
            action = "subtract from";
        }
        System.out.println("Type u to " + action + " the wallet's US currency or any other character to " + action + " the wallet's CIS22C currency.");
        String currency = sc.next();
        String note = "";
        boolean isUSDollar = true;
        if (currency.equals("u")) {
            isUSDollar = true;
            note = "US dollar";
        } else {
            isUSDollar = false;
            note = "CIS22C dollar";
        }
        System.out.println("How many " + note + "s would you like to " + action + " the wallet?");
        int inputedNotes = sc.nextInt();
        System.out.println("How many parts would you like to " + action + " the wallet?");
        int inputedCoins = sc.nextInt();

        if (isUSDollar) {
            Dollar d = new Dollar(inputedNotes, inputedCoins, note);
            if (adding) {
                w.addDollar(d);
            } else {
                w.subtractDollar(d);
            }
        } else {
            CIS22CDollar c = new CIS22CDollar(inputedNotes, inputedCoins, note);
            if (adding) {
                w.addCIS22CDollar(c);
            } else {
                w.subtractCIS22CDollar(c);
            }
        }
    }
}