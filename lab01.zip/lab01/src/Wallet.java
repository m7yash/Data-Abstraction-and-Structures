
/**
 * Lab 1
 *
 * @author: Yash Mishra
 * This is the Wallet Class. The Wallet object initializes the bills array to store a US Dollar and a CIS22C Dollar.
 * Lab One is meant to represent a Currency Simulator.
 */

public class Wallet {
    private Dollar[] bills = new Dollar[2];

    /**
     * Creates a Wallet and initializes bills array. Wallet has no value.
     */
    public Wallet() {
        Dollar d = new Dollar();
        this.bills[0] = d;
        CIS22CDollar c = new CIS22CDollar();
        this.bills[1] = c;
    }

    /**
     * get method for bills
     * @return bills array
     */
    public Dollar[] getBills() {
        return this.bills;
    }

    /**
     * PRE: Dollar object is taken
     * POST: Dollar object is added to the 0th index of bills array
     * add method for dollar
     * @param d dollar to be added
     */
    public void addDollar(Dollar d) {
        this.bills[0].add(d);
    }

    /**
     * PRE: CIS22CDollar object is taken
     * POST: CIS22CDollar object is added to the 1st index of bills array
     * add method for CIS22CDollar
     * @param c CIS22CDollar to be added
     */
    public void addCIS22CDollar(CIS22CDollar c) {
        CIS22CDollar cis22CDollar = (CIS22CDollar) this.bills[1];
        cis22CDollar.add(c);
    }

    /**
     * PRE: Dollar object is taken
     * POST: Dollar object is subtracted from the 0th index of bills array
     * subtract method for dollar
     * @param d dollar to be added
     */
    public void subtractDollar(Dollar d) {
        this.bills[0].subtract(d);
    }

    /**
     * PRE: CIS22CDollar object is taken
     * POST: CIS22CDollar object is subtracted from the 1st index of bills array
     * subtract method for CIS22CDollar
     * @param c CIS22CDollar to be added
     */
    public void subtractCIS22CDollar(CIS22CDollar c) {
        CIS22CDollar cis22CDollar = (CIS22CDollar) this.bills[1];
        cis22CDollar.subtract(c);
    }

    /**
     * checks if a dollar is greater than the total amount of dollars in the wallet
     * @param d dollar used for comparison to the wallet
     * @return true if the dollar is greater than the total amount of dollars in the wallet, false otherwise
     */
    public boolean greaterThanDollarTotal(Dollar d) {
        Dollar walletDollars = this.bills[0];
        return walletDollars.biggerDollar(d).equals(d);
    }

    /**
     * checks if a CIS22CDollar is greater than the total amount of CIS22CDollars in the wallet
     * @param c CIS22CDollar used for comparison to the wallet
     * @return true if the CIS22CDollar is greater than the total amount of CIS22CDollars in the wallet, false otherwise
     */
    public boolean greaterThanCIS22CDollarTotal(CIS22CDollar c) {
        CIS22CDollar walletCIS22CDollars = (CIS22CDollar) this.bills[1];
        return walletCIS22CDollars.biggerCIS22CDollar(c).equals(c);
    }

    /**
     * prints out the contents of the wallet using the Dollar's print() method
     * PRE: none
     * POST: three statements are printed
     */
    public void print() {
        System.out.println("Here are the contents of the wallet:");
        this.bills[0].print();
        this.bills[1].print();
    }
}
