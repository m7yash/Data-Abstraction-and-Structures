import java.util.Scanner;

/**
 * @author Yash Mishra
 * Lab2Main represents the main class of this project. It has the main method, primary helper functions, and secondary
 * help functions
 */
public class Lab2Main {

    private static Scanner sc = new Scanner(System.in);
    final static int SORT_MAX_SIZE = 16;

    /**
     * Checks if a method is Prime
     * method isPrimeNumber(num)
     *      print "Entering isPrimeNumber"
     *      if (num is less than 2)
     *          print "Leaving isPrimeNumber"
     *          return false
     *      end if
     *      integer i is 2
     *      loop (i < num)
     *          if (num modulus i is equal to 0)
     *              print "Leaving isPrimeNumber"
     *              return false
     *          i = i + 1
     *      end loop
     *      print "Leaving isPrimeNumber"
     *      return true
     * end isPrimeNumber
     * PRE: num to be checked for being prime
     * POST: true if num is prime or false if it is not prime
     * @param num number that will be checked for being prime
     * @return true if num is prime or false if it is not prime
     */
    public static boolean isPrimeNumber(int num) {
        System.out.println("    Entering isPrimeNumber");
        if (num < 2) {
            System.out.println("    Leaving isPrimeNumber");
            return false;
        }
        int i = 2;
        while (i < num) {
            if (num % i == 0) {
                System.out.println("    Leaving isPrimeNumber");
                return false;
            }
            i++;
        }
        System.out.println("    Leaving isPrimeNumber");
        return true;
    }

    /**
     * Checks if an array of integers consists of only prime numbers using a loop to iterate through the values
     * method isArrayPrimeIter(arr, size)
     *      print "Entering isArrayPrimeIter"
     *      loop (i is less than size starting from 0)
     *          if (NOT isPrimeNumber(element at index i in arr)
     *              print "Leaving isArrayPrimeIter"
     *              return false
     *          end if
     *      end loop
     *      print "Leaving isArrayPrimeIter"
     *      return true
     * end isArrayPrimeIter
     * PRE: array and size of array is passed
     * POST: true if array has all prime numbers, false otherwise
     *
     * @param arr  array with integers that will individually checked for being prime
     * @param size size of the parameter array
     * @return true if all integers in parameter array are prime or false if any number is not prime
     */
    public static boolean isArrayPrimeIter(int[] arr, int size) {
        System.out.println("Entering isArrayPrimeIter");
        for (int i = 0; i < size; i++) {
            if (!isPrimeNumber(arr[i])) {
                System.out.println("Leaving isArrayPrimeIter");
                return false;
            }
        }
        System.out.println("Leaving isArrayPrimeIter");
        return true;
    }

    /**
     * Checks if an array of integers consists of only prime numbers using recursion
     * method isArrayPrimeRecur(arr, size)
     *      print "Entering isArrayPrimeRecur"
     *      size = size - 1
     *      if (isPrimeNumber(element at index size in arr))
     *          if (size is equal to 0)
     *              print "Leaving isArrayPrimeRecur important"
     *              return true
     *          else
     *              return isArrayPrimeRecur(arr, size)
     *          end if
     *      end if
     *      print "Leaving isArrayPrimeRecur important"
     *      return false
     * end isArrayPrimeRecur
     * PRE: array and size of array is passed
     * POST: true if array has all prime numbers, false otherwise
     *
     * @param arr  array with integers that will individually checked for being prime
     * @param size size of the parameter array
     * @return true if all integers in parameter array are prime or false if any number is not prime
     */
    public static boolean isArrayPrimeRecur(int[] arr, int size) {
        System.out.println("Entering isArrayPrimeRecur");
        size--;
        if (isPrimeNumber(arr[size])) {
            if (size == 0) {
                System.out.println("Leaving isArrayPrimeRecur important");
                return true;
            } else {
                return isArrayPrimeRecur(arr, size);
            }
        }
        System.out.println("Leaving isArrayPrimeRecur");
        return false;
    }

    /**
     * Main method that takes user input for the number of elements and value of those elements to check for if all numb
     * ers are prime
     *
     * @param args args passed in to main method
     */
    public static void main(String[] args) {
        System.out.println("Enter the number of elements.");
        int numElements = 1; //default initial value, real value will be defined in next while loop
        while (true) {
            numElements = sc.nextInt();
            if (numElements < 1 || numElements > SORT_MAX_SIZE) {
                System.out.println("Please try again. The number of elements need to between 1 and 16.");
            } else {
                break;
            }
        }

        int[] array = new int[numElements];

        int iterator = 0;
        while (iterator < numElements) {
            System.out.println("Enter the number for index " + iterator);
            int element = sc.nextInt();
            if (element < 1 || element > 99) {
                System.out.println("Please try again. Your number must be between 1 and 99 inclusive.");
            } else {
                array[iterator] = element;
                iterator++;
            }
        }

        String s = "Array Contents: " + array[0];

        for (int i = 1; i < array.length; i++) {
            s += ", " + array[i];
        }

        System.out.println("");
        System.out.println(s);
        System.out.println("");

        if (isArrayPrimeIter(array, array.length)) {
            System.out.println("");
            System.out.println("Prime Array using iteration.");
        } else {
            System.out.println("");
            System.out.println("Not a Prime Array using iteration.");
        }
        System.out.println("");
        if (isArrayPrimeRecur(array, array.length)) {
            System.out.println("");
            System.out.println("Prime Array using recursion.");
        } else {
            System.out.println("");
            System.out.println("Not a Prime Array using recursion.");
        }
    }
}