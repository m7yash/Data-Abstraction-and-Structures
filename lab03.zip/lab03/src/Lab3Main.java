import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import java.io.PrintStream;

/**
 * Lab 3
 *
 * @author: Yash Mishra
 * This is the Main Class. It has the main method, sort method, and various helper methods.
 * The purpose of the program is to sort Dollar or CIS22CDollar objects as entered by the user.
 */
public class Lab3Main {
    private static Scanner sc = new Scanner(System.in);
    final static int SORT_MAX_SIZE = 16;
    static boolean typeIsDollar;
    static File file = new File("outputfile.txt");
    static PrintStream stream;

    static {
        try {
            stream = new PrintStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    static PrintStream console = System.out;

    /**
     * main method of the program, takes user input with helper methods for validation and calls the sort method
     *
     * @param args to run the program with
     */
    public static void main(String[] args) {
        print("Enter the number of elements that you will enter.");
        int numElements = validateNumElements(1, SORT_MAX_SIZE);

        print("Type d if you will enter Dollars. Or, type any other character if you will enter CIS22CDollars.");
        String dataTypeInput = sc.next();
        printToOutputFile(dataTypeInput);

        Dollar[] bills = new Dollar[numElements];

        if (dataTypeInput.equals("d")) {
            typeIsDollar = true;
        } else {
            typeIsDollar = false;
            bills = new CIS22CDollar[numElements];
        }

        validateIndividualElements(bills, numElements);

        print("Beginning Mergesort!");
        print("-----------------------------------------------");
        recurMergeSort(bills, 0, numElements - 1);
        generateReport(bills);
        print("Mergesort complete!");
    }

    /**
     * validates user input for the total number of elements, ensures it is an integer value and is between parameters
     *
     * @param lower bound for input value
     * @param upper bound for input value
     * @return total number of elements as set by the user
     */
    public static int validateNumElements(int lower, int upper) {
        int numElements = 0; //default
        while (true) {
            String s = sc.next();
            printToOutputFile(s);
            try {
                numElements = Integer.parseInt(s);
                if (numElements < lower || numElements > upper) {
                    print("Please try again. The number of elements need to between 1 and 16.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                print("Please try again. You must enter an integer number.");
            }
        }
        return numElements;
    }

    /**
     * validates the elements to be added to the array, ensures elements are integer values
     *
     * @param arr   dollar array that input values will be added to
     * @param total total number of elements
     */
    public static void validateIndividualElements(Dollar[] arr, int total) {
        String s = "Dollar";
        if (!typeIsDollar) {
            s = "CIS22CDollar";
        }
        int iterator = 0;
        while (iterator < total) {
            print("Enter the number of " + s + "s at index " + iterator);
            String dollarValInput = sc.next();
            printToOutputFile(dollarValInput + "");

            print("Enter the number of parts at index " + iterator);
            String partValInput = sc.next();
            printToOutputFile(partValInput + "");
            try {
                int dollarVal = Integer.parseInt(dollarValInput);
                int partVal = Integer.parseInt(partValInput);

                if (typeIsDollar) {
                    Dollar d = new Dollar();
                    d.add(new Dollar(dollarVal, partVal, s));
                    arr[iterator] = d;
                } else {
                    CIS22CDollar c = new CIS22CDollar();
                    c.add(new CIS22CDollar(dollarVal, partVal, s));
                    arr[iterator] = c;
                }
                iterator++;
            } catch (NumberFormatException e) {
                print("You entered a non-integer whole or fractional part. Please try re-entering values for that " + s + ".");
            }
        }
    }

    /**
     * helper method for printing statements to both the output file and the console
     *
     * @param s string to be printed
     */
    public static void print(String s) {
        printToOutputFile(s);
        printToConsole(s);
    }

    /**
     * helper method to print statements to the output file
     *
     * @param s string to be printed
     */
    public static void printToOutputFile(String s) {
        System.setOut(stream);
        System.out.println(s);
    }

    /**
     * helper method to print statements to the console file
     *
     * @param s string to be printed
     */
    public static void printToConsole(String s) {
        System.setOut(console);
        System.out.println(s);
    }

    /**
     * prints out the value of each bill
     *
     * @param bills array of Dollar or CIS22CDollar objects that will have individual values be printed
     */
    public static void generateReport(Dollar[] bills) {
        for (int i = 0; i < bills.length; i++) {
            String report = bills[i].getNoteName() + " value: " + bills[i].getWholePart() + " dollars and " + bills[i].getFractionalPart() + " parts.";
            print(report);
        }
        print("-----------------------------------------------");
    }

    /**
     * recursive merge sort algorithm for array of Dollar or CIS22CDollar Objects
     * PRE: unsorted array
     * POST: array sorted in descending order
     *
     * @param arr   array to be sorted
     * @param first first index of array
     * @param last  last index of array
     */
    public static void recurMergeSort(Dollar arr[], int first, int last) {
        if (first < last) {
            int mid = (first + last) / 2;
            recurMergeSort(arr, first, mid);
            recurMergeSort(arr, mid + 1, last);
            merge(arr, first, mid, last);
        }
    }

    /**
     * helper method for merge sort algorithm, also prints individuals dollar values
     * @param arr   array used for merging
     * @param first first index of array
     * @param mid   middle between first and last indexes of array
     * @param last  last index of array
     */
    public static void merge(Dollar arr[], int first, int mid, int last) {
        generateReport(arr);
        Dollar[] temp = new Dollar[arr.length];
        int first1 = first;
        int last1 = mid;
        int first2 = mid + 1;
        int last2 = last;

        int index = first1;

        while ((first1 <= last1) && (first2 <= last2)) {
            boolean comparison;
            if (typeIsDollar) {
                comparison = arr[first1].biggerDollar(arr[first2]).equals(arr[first2]);
            } else {
                CIS22CDollar c1 = (CIS22CDollar) arr[first1];
                CIS22CDollar c2 = (CIS22CDollar) arr[first2];
                comparison = c1.biggerCIS22CDollar(c2).equals(c2);
            }
            if (comparison) {
                temp[index] = arr[first2];
                first2++;
            } else {
                temp[index] = arr[first1];
                first1++;
            }
            index++;
        }
        while (first1 <= last1) {
            temp[index] = arr[first1];
            first1++;
            index++;
        }
        while (first2 <= last2) {
            temp[index] = arr[first2];
            first2++;
            index++;
        }
        for (index = first; index <= last; index++) {
            arr[index] = temp[index];
        }
    }
}