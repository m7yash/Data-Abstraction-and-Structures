/**
 * @author Yash Mishra
 * Lab 4 shows an implementation of a Linked List, Stack, and Queue
 * Lab4Main takes user input and runs demonstrations
 */
public class Lab4Main {
    /**
     * main method generates 7 random Nodes
     * @param args for the program
     */
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        SinglyLinkedListStack s = new SinglyLinkedListStack();
        SinglyLinkedListQueue q = new SinglyLinkedListQueue();

        Dollar[] dollars = new Dollar[7];

        System.out.println("Welcome!");
        System.out.println("Here are the randomly generated Link Nodes that we will work with.");

        for (int i = 0; i < 7; i++) {
            int dollar = (int) (100 * Math.random());
            int cent = (int) (100 * Math.random());
            Dollar d = new Dollar(dollar, cent, "dollar");
            dollars[i] = d;
            System.out.println("Link Node " + (i + 1) + " has " + dollar + " dollars and " + cent + " cents ");
        }
        System.out.println();
        linkedListDemo(list, dollars);
        System.out.println();
        stackDemo(s, dollars);
        System.out.println();
        queueDemo(q, dollars);
    }

    /**
     * demonstrates the addData, print, remove, and findData methods of Linked List
     * @param list is the list to edit
     * @param dollars nodes to add to the list
     */
    public static void linkedListDemo(SinglyLinkedList list, Dollar[] dollars) {
        System.out.println("Now I will demonstrate the use of the Singly Linked List.");
        System.out.println("I will add the Link Nodes in a random order.");
        list.addData(new LinkNode(dollars[3], null));
        list.addData(new LinkNode(dollars[0], null));
        list.addData(new LinkNode(dollars[2], null));
        list.addData(new LinkNode(dollars[1], null));
        list.addData(new LinkNode(dollars[5], null));
        list.addData(new LinkNode(dollars[4], null));
        list.addData(new LinkNode(dollars[6], null));
        System.out.println("Nodes have been added. Here is what the list looks like right now.");
        list.print();
        System.out.println("Now, I will remove the first and last node");
        list.removeFirstData();
        list.removeLastData();
        list.print();
        System.out.println("Now I will remove the third node");
        list.removeData(2);
        list.print();
        System.out.println("Now I will identify the second node");
        list.findData(1).getData().print();
        System.out.println("Now I will add a Node with Value $7.25 to the end.");
        list.addData(new LinkNode(new Dollar(7, 25, "dollar"), null));
        System.out.println("Now I will print the list again.");
        list.print();
        System.out.println("Singly Linked List Demo Complete.");
    }

    /**
     * demonstrates the push, print, pop, and peek methods of Stack
     * @param s is the stack to edit
     * @param dollars nodes to add to the stack
     */
    public static void stackDemo(Stack s, Dollar[] dollars) {
        System.out.println("Now I will demonstrate the use of the Stack.");
        System.out.println("I will push the Link Nodes in a random order.");
        System.out.println("Nodes have been pushed. Here is what the list looks like right now. Top of the stack is printed last.");
        s.push(new LinkNode(dollars[4], null));
        s.push(new LinkNode(dollars[3], null));
        s.push(new LinkNode(dollars[0], null));
        s.push(new LinkNode(dollars[6], null));
        s.push(new LinkNode(dollars[2], null));
        s.push(new LinkNode(dollars[1], null));
        s.push(new LinkNode(dollars[5], null));
        s.print();
        System.out.println("Now, I will pop one node from the stack and then peek.");
        s.pop();
        s.peek();
        System.out.println("Now I will pop three nodes from the stack and then peek.");
        s.pop();
        s.pop();
        s.pop();
        s.peek();
        System.out.println("Now I will push a Node with Value $7.25");
        s.push(new LinkNode(new Dollar(7, 25, "dollar"), null));
        System.out.println("Now I will print the stack again.");
        s.print();
        System.out.println("Stack Demo Complete.");
    }

    /**
     * demonstrates the queue, print, dequeue, peekFront, and peekRear methods of Queue
     * @param q is the queue to edit
     * @param dollars nodes to add to the queue
     */
    public static void queueDemo(Queue q, Dollar[] dollars) {
        System.out.println("Now I will demonstrate the use of the Queue.");
        System.out.println("I will queue the Link Nodes in a random order and print the node being queued so the entire stack is printed.");
        System.out.println("Nodes have been queued. Here is what the list looks like right now. Front of the queue is first in the list.");
        q.enqueue(new LinkNode(dollars[6], null));
        q.enqueue(new LinkNode(dollars[2], null));
        q.enqueue(new LinkNode(dollars[4], null));
        q.enqueue(new LinkNode(dollars[3], null));
        q.enqueue(new LinkNode(dollars[5], null));
        q.enqueue(new LinkNode(dollars[0], null));
        q.enqueue(new LinkNode(dollars[1], null));
        q.print();
        System.out.println("Now, I will peek at the rear.");
        q.peekRear();
        System.out.println("Now, I will dequeue one node from the queue and then peek at the front.");
        q.dequeue();
        q.peekFront();
        System.out.println("Now, I will dequeue three nodes from the queue and then peek at the front.");
        q.dequeue();
        q.dequeue();
        q.dequeue();
        q.peekFront();
        System.out.println("Now, I will peek at the rear again.");
        q.peekRear();
        System.out.println("Now I will queue a Node with Value $7.25");
        q.enqueue(new LinkNode(new Dollar(7, 25, "dollar"), null));
        System.out.println("Now I will print the queue again.");
        q.print();
        System.out.println("Queue Demo Complete.");
    }
}
