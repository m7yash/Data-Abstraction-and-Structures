/**
 * interface to restrict Queue methods. documentation of each method is in SinglyLinkedListQueue class.
 */
public interface Queue {
    public void enqueue(LinkNode l);

    public void dequeue();

    public void peekFront();

    public void peekRear();

    public void destroy();

    public void print();
}
