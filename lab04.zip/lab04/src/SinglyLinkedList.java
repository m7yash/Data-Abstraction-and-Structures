/**
 * Represents a Singly Linked List Object
 */
public class SinglyLinkedList {

    private int count;
    private LinkNode start;
    private LinkNode end;

    /**
     * constructor for this Singly Linked List
     */
    public SinglyLinkedList() {
        this.count = 0;
        this.start = null;
        this.end = null;
    }

    /**
     * adds a LinkNode to the end of the Linked List
     * @param n LinkNode to be added to the Linked List
     * @return true after the addition completes
     */
    public boolean addData(LinkNode n)
    {
        if (isEmpty()) {
            start = n;
        } else {
            end.setNext(n);
        }
        end = n;
        count++;
        return true;
    }

    /**
     * removes the first Link Node in the Linked List
     * @return false if the list is empty, true if the Link Node was removed
     */
    public boolean removeFirstData() {
        if (isEmpty()) {
            return false;
        }
        start = start.getNext();
        count--;
        return true;
    }

    /**
     * removes the Link Node at a specified index
     * @param index of Link Node to be removed
     * @return false if the list is empty, true if the Link Node was removed
     */
    public boolean removeData(int index) {
        if (isEmpty()) {
            return false;
        }
        LinkNode currentNode = start;
        for (int i = 0; i < index - 1; i++) {
            currentNode = currentNode.getNext();
        }
        currentNode.setNext(currentNode.getNext().getNext());
        count--;
        return true;
    }

    /**
     * removes the last Link Node in the Linked List
     * @return false if the list is empty, true if the last Link Node was removed
     */
    public boolean removeLastData() {
        if (count == 1)
        {
            return removeFirstData();
        }
        boolean b = removeData(count - 1);
        LinkNode currentNode = start;
        for (int i = 0; i < count - 1; i++) {
            currentNode = currentNode.getNext();
        }
        end = currentNode;
        return b;
    }

    /**
     * returns the Link Node at a specified index
     * @param index to find the Link Node at
     * @return the Link Node at the index
     */
    public LinkNode findData(int index) {
        LinkNode currentNode = start;
        for (int i = 0; i < index; i++) {
            currentNode = currentNode.getNext();
        }
        return currentNode;
    }

    /**
     * removes all Link Nodes in the Linked List
     */
    public void destroy() {
        if (isEmpty())
        {
            return;
        }
        removeFirstData();
        destroy();
    }

    /**
     * method used to check if list is empty
     * @return true if the list is empty, false otherwise
     */
    public boolean isEmpty() {
        if (start == null) {
            return true;
        }
        return false;
    }

    /**
     * prints the data values of the Link Nodes in the List
     */
    public void print() {
        if (isEmpty()) {
            System.out.println("Empty list.");
        } else {
            LinkNode currentNode = start;
            for (int i = 0; i < count; i++) {
                currentNode.getData().print();
                currentNode = currentNode.getNext();
            }
        }
    }

    /**
     * get method for count
     * @return count
     */
    public int getCount() {
        return count;
    }

    /**
     * set method for count
     * @param count is the new value of count
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * get method for start
     * @return start
     */
    public LinkNode getStart() {
        return start;
    }

    /**
     * set method for start
     * @param start is the new value of start
     */
    public void setStart(LinkNode start) {
        this.start = start;
    }

    /**
     * get method for end
     * @return end
     */
    public LinkNode getEnd() {
        return end;
    }

    /**
     * set method for end
     * @param end is the new value of end
     */
    public void setEnd(LinkNode end) {
        this.end = end;
    }
}
