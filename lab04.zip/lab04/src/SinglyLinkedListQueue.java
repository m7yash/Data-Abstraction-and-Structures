/**
 * Represents a Queue based on the Singly Linked List
 */
public class SinglyLinkedListQueue extends  SinglyLinkedList implements Queue {

    /**
     * constructor for the queue
     */
    public SinglyLinkedListQueue()
    {
        super();
    }

    /**
     * adds a LinkNode to the end of the queue
     * @param l LinkNode to be added
     */
    public void enqueue(LinkNode l)
    {
        addData(l);
    }

    /**
     * removes the LinkNode at the front of the queue
     */
    public void dequeue()
    {
        removeFirstData();
    }

    /**
     * returns the LinkNode at the front of the queue
     */
    public void peekFront()
    {
        findData(0).getData().print();
    }

    /**
     * returns the LinkNode at the end of the queue
     */
    public void peekRear()
    {
        findData(getCount() - 1).getData().print();
    }
}
