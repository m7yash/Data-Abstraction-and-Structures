/**
 * Represents a Stack based on the Singly Linked List
 */
public class SinglyLinkedListStack extends  SinglyLinkedList implements  Stack {

    /**
     * constructor for the stack
     */
    public SinglyLinkedListStack()
    {
        super();
    }

    /**
     * adds a Link Node to the top
     * @param l Link Node to be added
     */
    public void push(LinkNode l)
    {
        addData(l);
    }

    /**
     * removes the top Link Node
     */
    public void pop()
    {
        removeLastData();
    }

    /**
     * returns the top Link Node
     */
    public void peek()
    {
        findData(getCount() - 1).getData().print();
    }
}
