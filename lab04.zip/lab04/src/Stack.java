/**
 * interface to restrict Stack methods. documentation of each method is in SinglyLinkedListStack class.
 */
public interface Stack {

    public void push(LinkNode l);

    public void pop();

    public void peek();

    public void destroy();

    public void print();
}
