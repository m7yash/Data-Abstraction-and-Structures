/**
 * represents a Binary Search Tree
 */
public class BST {
    private BSTNode root;
    private Queue q = new SinglyLinkedListQueue();

    /**
     * constructs an empty Binary Search Tree by setting the root to null
     */
    public BST() {
        root = null;
    }

    /**
     * inserts a node into the Binary Search Tree, maintaining BST rules
     *
     * @param root    root of the tree
     * @param newNode node to be inserted into the BST
     * @return the root of the tree
     */
    public BSTNode insert(BSTNode root, BSTNode newNode) {
        if (root == null) {
            root = newNode;
            root.setLeft(null);
            root.setRight(null);
            return root;
        }
        if (newNode.getData().biggerDollar(root.getData()).equals(root.getData())) {
            root.setLeft(insert(root.getLeft(), newNode));
        } else if (newNode.getData().biggerDollar(root.getData()).equals(newNode.getData())) {
            root.setRight(insert(root.getRight(), newNode));
        }
        return root;
    }

    /**
     * searches for a target node in the tree
     *
     * @param root   root of the tree
     * @param target target node that is being searched for
     * @return returns the address of the BSTNode that is searched for, null if it is not in the tree
     */
    public BSTNode search(BSTNode root, BSTNode target) {
        if (root == null || root.getData().equals(target.getData())) {
            return root;
        }
        if (target.getData().biggerDollar(root.getData()).equals(target.getData())) {
            return search(root.getRight(), target);
        }
        return search(root.getLeft(), target);
    }

    /**
     * deletes the target node from the BST
     *
     * @param root   root of the tree
     * @param target target node that is being deleted
     * @return address of the deleted node, or null if it is not found
     */
    public BSTNode delete(BSTNode root, Dollar target) {
        if (root == null) {
            return null;
        }
        if (root.getData().equals(target)) {
            if (root.getLeft() == null) {
                return root.getRight();
            } else if (root.getRight() == null) {
                return root.getLeft();
            }
            root.setData(smallestValue(root.getRight()));
            root.setRight(delete(root.getRight(), root.getData()));
            return root;
        }
        if (target.biggerDollar(root.getData()).equals(root.getData())) {
            root.setLeft(delete(root.getLeft(), target));
        } else if (target.biggerDollar(root.getData()).equals(target)) {
            root.setRight(delete(root.getRight(), target));
        }
        return root;
    }

    /**
     * helper method to find the smallest value in a tree
     *
     * @param root root of the tree
     * @return the smallest dollar value in the tree
     */
    public Dollar smallestValue(BSTNode root) {
        Dollar minimum = root.getData();
        while (root.getLeft() != null) {
            minimum = root.getLeft().getData();
            root = root.getLeft();
        }
        return minimum;
    }

    /**
     * traverses the tree horizontally and prints the contents
     *
     * @param root root of the tree
     */
    public void breadthFirstOrder(BSTNode root) {
        int numLevels = maxDepth(root);
        for (int i = 0; i < numLevels; i++) {
            q.destroy();
            printKDistant(root, i);
            q.print();
        }
    }

    /**
     * helper method to add all nodes in a level to q
     *
     * @param node represents current node in the recursive function
     * @param k    represents the level that everything will be printed from
     */
    public void printKDistant(BSTNode node, int k) {
        if (node == null)
            return;
        if (k == 0) {
            q.enqueue(new LinkNode(node.getData(), null));
            return;
        } else {
            printKDistant(node.getLeft(), k - 1);
            printKDistant(node.getRight(), k - 1);
        }
    }

    /**
     * helper method that finds the maximum depth in the tree
     *
     * @param node represents the current node in the recursive function
     * @return the maximum depth in the tree
     */
    public int maxDepth(BSTNode node) {
        if (node == null)
            return 0;
        else {
            int lDepth = maxDepth(node.getLeft());
            int rDepth = maxDepth(node.getRight());

            if (lDepth > rDepth) {
                return (lDepth + 1);
            } else {
                return (rDepth + 1);
            }
        }
    }

    /**
     * helper method that determines the size of the entire tree
     *
     * @param node represents the current node in the recursive function
     * @return the number of nodes in the tree
     */
    public int size(BSTNode node) {
        if (node == null) {
            return 0;
        } else {
            return (1 + size(node.getLeft()) + size(node.getRight()));
        }
    }

    /**
     * traverses the tree with preOrder method
     *
     * @param root root of the tree
     */
    public void preOrder(BSTNode root) {
        if (root != null) {
            root.getData().print();
            preOrder(root.getLeft());
            preOrder(root.getRight());
        }
    }

    /**
     * traverses the tree with inOrder method
     *
     * @param root root of the tree
     */
    public void inOrder(BSTNode root) {
        if (root != null) {
            inOrder(root.getLeft());
            root.getData().print();
            inOrder(root.getRight());
        }
    }

    /**
     * traverses the tree with postOrder method
     *
     * @param root root of the tree
     */
    public void postOrder(BSTNode root) {
        if (root != null) {
            postOrder(root.getLeft());
            postOrder(root.getRight());
            root.getData().print();
        }
    }

    /**
     * determines if the tree has any nodes
     *
     * @return true of the tree has no nodes, false if it has any
     */
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * returns the root of the Binary Search Tree
     *
     * @return root of the tree
     */
    public BSTNode getRoot() {
        return root;
    }

    /**
     * edits what the root of the tree refers to
     *
     * @param root root of the tree
     */
    public void setRoot(BSTNode root) {
        this.root = root;
    }
}
