/**
 * represents a single tree node
 */
public class BSTNode {
    private Dollar data;
    private BSTNode left;
    private BSTNode right;

    /**
     * creates a BSTNode object based on a dollar value
     * @param d dollar value of the data field
     */
    public BSTNode(Dollar d)
    {
        data = d;
        left = null;
        right = null;
    }

    /**
     * get method for the data field
     * @return dollar values of the data
     */
    public Dollar getData() {
        return data;
    }

    /**
     * edits the data field of the BSTNode object
     * @param data new dollar value of the data field
     */
    public void setData(Dollar data) {
        this.data = data;
    }

    /**
     * get method for the left child BSTNode
     * @return left child
     */
    public BSTNode getLeft() {
        return left;
    }

    /**
     * edits the left child BSTNode
     * @param left new BSTNode that left will be a reference to
     */
    public void setLeft(BSTNode left) {
        this.left = left;
    }

    /**
     * get method for the right child BSTNode
     * @return right child
     */
    public BSTNode getRight() {
        return right;
    }

    /**
     * edits the right child BSTNode
     * @param right new BSTNode that right will be a reference to
     */
    public void setRight(BSTNode right) {
        this.right = right;
    }
}
