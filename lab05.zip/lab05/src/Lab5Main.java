import java.io.*;
import java.util.Scanner;

/**
 * @author Yash Mishra
 * Lab 5 allows the user to enter nodes into a tree and then manipulate that tree
 * The Lab5Main class manages user input and output
 */
public class Lab5Main {
    private static Scanner sc = new Scanner(System.in);
    static File file = new File("outputfile.txt");
    static PrintStream stream;
    public PrintStream publicStream = stream;

    static {
        try {
            stream = new PrintStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    static PrintStream console = System.out;
    public PrintStream publicConsole = console;

    /**
     * Creates nodes based on user input, then allows addition, searching, deletion, printing, or exiting
     * the methods that are called here have input validation
     * @param args for the program
     */
    public static void main(String[] args) throws IOException {
        print("Welcome!");
        print("Enter some data!");
        Dollar[] dollars = new Dollar[10];
        validateIndividualElements(dollars, 10);
        BST tree = new BST();
        tree.setRoot(new BSTNode(dollars[0]));
        for (int i = 1; i < 10; i++) {
            tree.insert(tree.getRoot(), new BSTNode(dollars[i]));
        }
        while (true) {
            print("Type a to add a node, s to search a node, d to delete a node, p to print the tree, or any other character to exit");
            String command = sc.next();
            printToOutputFile("" + command);
            if (command.equals("a")) {
                add(tree);
            } else if (command.equals("s")) {
                search(tree);
            } else if (command.equals("d")) {
                delete(tree);
            } else if (command.equals("p")) {
                report(tree);
            } else {
                report(tree);
                print("Exiting program.");
                break;
            }
        }
    }

    /**
     * validates the elements for initial tree composition
     * @param arr array of dollar elements to add new objects to
     * @param total number of elements in the array
     */
    public static void validateIndividualElements(Dollar[] arr, int total) {
        int iterator = 0;
        while (iterator < total) {
            print("Enter the number of Dollars at index " + iterator);
            String dollarValInput = sc.next();
            printToOutputFile(dollarValInput + "");
            print("Enter the number of parts at index " + iterator);
            String partValInput = sc.next();
            printToOutputFile(partValInput + "");
            try {
                int dollarVal = Integer.parseInt(dollarValInput);
                int partVal = Integer.parseInt(partValInput);
                Dollar d = new Dollar();
                d.add(new Dollar(dollarVal, partVal, "dollar"));
                arr[iterator] = d;
                iterator++;
            } catch (NumberFormatException e) {
                print("You entered a non-integer whole or fractional part. Please try re-entering values for that dollar.");
            }
        }
    }

    /**
     * takes user input, creates a BSTNode with the dollar object, adds it to the tree
     * validates the input
     * @param tree tree being used in the program
     */
    public static void add(BST tree) {
        while (true) {
            print("What dollar value would you like to add?");
            String dollarToAdd = sc.next();
            printToOutputFile("" + dollarToAdd);
            print("What cent value would you like to add?");
            String centToAdd = sc.next();
            printToOutputFile("" + centToAdd);
            try {
                int doll = Integer.parseInt(dollarToAdd);
                int cent = Integer.parseInt(centToAdd);
                Dollar d = new Dollar(doll, cent, "dollar");
                tree.insert(tree.getRoot(), new BSTNode(d));
                break;
            } catch (NumberFormatException e) {
                print("You entered a non-integer whole or fractional part. Please try re-entering values for that dollar.");
            }
        }
    }

    /**
     * takes user input, creates a BSTNode with the dollar object, searches for it in the tree
     * validates the input
     * @param tree tree being used in the program
     */
    public static void search(BST tree) {
        while (true) {
            print("What dollar value would you like to search for?");
            String dollarToSearchFor = sc.next();
            printToOutputFile("" + dollarToSearchFor);
            print("What cent value would you like to search for?");
            String centToSearchFor = sc.next();
            printToOutputFile("" + centToSearchFor);
            try {
                int doll = Integer.parseInt(dollarToSearchFor);
                int cent = Integer.parseInt(centToSearchFor);
                Dollar d = new Dollar(doll, cent, "dollar");
                print("" + tree.search(tree.getRoot(), new BSTNode(d)));
                break;
            } catch (NumberFormatException e) {
                print("You entered a non-integer whole or fractional part. Please try re-entering values for that dollar.");
            }
        }
    }

    /**
     * takes user input, creates a BSTNode with the dollar object, deletes it from the tree
     * validates the input
     * @param tree tree being used in the program
     */
    public static void delete(BST tree) {
        while (true) {
            print("What is the dollar value of the node you would like to delete?");
            String dollarOfDeletion = sc.next();
            printToOutputFile("" + dollarOfDeletion);
            print("What is the cent value of the node you would like to delete?");
            String centOfDeletion = sc.next();
            printToOutputFile("" + centOfDeletion);
            try {
                int doll = Integer.parseInt(dollarOfDeletion);
                int cent = Integer.parseInt(centOfDeletion);
                Dollar d = new Dollar(doll, cent, "dollar");
                int preDeletionSize = tree.size(tree.getRoot());
                tree.delete(tree.getRoot(), d);
                int postDeletionSize = tree.size(tree.getRoot());
                if (postDeletionSize == preDeletionSize) {
                    print("Nothing was deleted");
                }
                break;
            } catch (NumberFormatException e) {
                print("You entered a non-integer whole or fractional part. Please try re-entering values for that dollar.");
            }
        }
    }

    /**
     * helper method for printing statements to both the output file and the console
     * @param s string to be printed
     */
    public static void print(String s) {
        printToConsole(s);
        printToOutputFile(s);
    }

    /**
     * helper method to print statements to the output file
     * @param s string to be printed
     */
    public static void printToOutputFile(String s) {
        System.setOut(stream);
        System.out.println(s);
        System.setOut(console);
    }

    /**
     * helper method to print statements to the console file
     * @param s string to be printed
     */
    public static void printToConsole(String s) {
        System.setOut(console);
        System.out.println(s);
    }

    /**
     * generates a report of the contents of the tree by doing breadth first traversal, inorder traversal, preorder traversal, and postorder traversal
     * @param tree tree being used in the program
     */
    public static void report(BST tree) {
        print("");
        print("Breadth First:");
        tree.breadthFirstOrder(tree.getRoot());
        print("");
        print("Inorder:");
        tree.inOrder(tree.getRoot());
        print("");
        print("Preorder:");
        tree.preOrder(tree.getRoot());
        print("");
        print("Postorder:");
        tree.postOrder(tree.getRoot());
    }
}
