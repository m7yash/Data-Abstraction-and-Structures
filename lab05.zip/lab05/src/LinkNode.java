public class LinkNode {

    private Dollar data;
    private LinkNode next;

    public LinkNode (Dollar data, LinkNode next)
    {
        this.data = data;
        this.next = next;
    }

    public Dollar getData() {
        return data;
    }

    public void setData(Dollar data) {
        this.data = data;
    }

    public LinkNode getNext() {
        return next;
    }

    public void setNext(LinkNode next) {
        this.next = next;
    }
}
